
c   Copyright (C) 2009  Javier Klett, Rub�n Gil-Redondo, Federico Gago and
c   Antonio Morreale

c   Based on the original work by �ngel R. Ortiz

c   The following terms apply to all files and documents associated with the 
c   software unless explicitly disclaimed in individual files. Do not 
c   redistribute the program. Interested users should contact directly to the 
c   authors. This software is for scientific non-profit and non-commercial use
c   only. Any other use of this software for other purposes, alone or 
c   integrated into other software, requires the prior consent of the authors.

c   IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
c   DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
c   OF THE USE OF THIS SOFTWARE, ITS DOCUMENTATION, OR ANY DERIVATIVES THEREOF,
c   EVEN IF THE AUTHORS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

c   THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES, 
c   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, 
c   FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.  THIS SOFTWARE IS 
c   PROVIDED ON AN "AS IS" BASIS, AND THE AUTHORS AND DISTRIBUTORS HAVE NO 
c   OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR 
c   MODIFICATIONS.

      real*8 fval(100)
      fval(1)= 199.500
      fval(2)= 19.000
      fval(3)= 9.552
      fval(4)= 6.944
      fval(5)= 5.786
      fval(6)= 5.143
      fval(7)= 4.737
      fval(8)= 4.459
      fval(9)= 4.256
      fval(10)= 4.103
      fval(11)= 3.982
      fval(12)= 3.885
      fval(13)= 3.806
      fval(14)= 3.739
      fval(15)= 3.682
      fval(16)= 3.634
      fval(17)= 3.592
      fval(18)= 3.555
      fval(19)= 3.522
      fval(20)= 3.493
      fval(21)= 3.467
      fval(22)= 3.443
      fval(23)= 3.422
      fval(24)= 3.403
      fval(25)= 3.385
      fval(26)= 3.369
      fval(27)= 3.354
      fval(28)= 3.340
      fval(29)= 3.328
      fval(30)= 3.316
      fval(31)= 3.305
      fval(32)= 3.295
      fval(33)= 3.285
      fval(34)= 3.276
      fval(35)= 3.267
      fval(36)= 3.259
      fval(37)= 3.252
      fval(38)= 3.245
      fval(39)= 3.238
      fval(40)= 3.232
      fval(41)= 3.226
      fval(42)= 3.220
      fval(43)= 3.214
      fval(44)= 3.209
      fval(45)= 3.204
      fval(46)= 3.200
      fval(47)= 3.195
      fval(48)= 3.191
      fval(49)= 3.187
      fval(50)= 3.183
      fval(51)= 3.179
      fval(52)= 3.175
      fval(53)= 3.172
      fval(54)= 3.168
      fval(55)= 3.165
      fval(56)= 3.162
      fval(57)= 3.159
      fval(58)= 3.156
      fval(59)= 3.153
      fval(60)= 3.150
      fval(61)= 3.148
      fval(62)= 3.145
      fval(63)= 3.143
      fval(64)= 3.140
      fval(65)= 3.138
      fval(66)= 3.136
      fval(67)= 3.134
      fval(68)= 3.132
      fval(69)= 3.130
      fval(70)= 3.128
      fval(71)= 3.126
      fval(72)= 3.124
      fval(73)= 3.122
      fval(74)= 3.120
      fval(75)= 3.119
      fval(76)= 3.117
      fval(77)= 3.115
      fval(78)= 3.114
      fval(79)= 3.112
      fval(80)= 3.111
      fval(81)= 3.109
      fval(82)= 3.108
      fval(83)= 3.107
      fval(84)= 3.105
      fval(85)= 3.104
      fval(86)= 3.103
      fval(87)= 3.101
      fval(88)= 3.100
      fval(89)= 3.099
      fval(90)= 3.098
      fval(91)= 3.097
      fval(92)= 3.095
      fval(93)= 3.094
      fval(94)= 3.093
      fval(95)= 3.092
      fval(96)= 3.091
      fval(97)= 3.090
      fval(98)= 3.089
      fval(99)= 3.088
      fval(100)= 3.087
